Title: A ( part1 ) Powerful Java Swing & JDBC Code for Application Development
Description: Hi Friends,(updated Oct25, 2003, version11)
I HAVE INCLUDED COMMENTS AND WORKING OF THIS CODE DUE TO DEMAND FROM MANY PROGRAMMERS ..,Thanks for the response u gave me for my previous codes, I am a hardcore PHP & Java Programmer, found PHP the best for Development of Dynamic Websites, But as a programmer getting lots of project of Different Types I found Java very good for Application Development, I saw many sites, nowhere could I find a clear description of how to use Java swing with JDBC to perform fundamental operations like add record, modify, delete record, view records & search reports using most of swing components like checkbox, radio button etc., either they were too complicated to install or horrible to understand, So I wrote this code .This will be very helpful for Application Development Programmers, in fact as u know u can call java applets and java programs from PHP So this could be a great advantage free source code. if u have any problems in installing , compiling or running this code please do mail me at james_smith73@yahoo.com
New Version of this code is available at http://www.geocities.com/james_smith73  

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3164&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
